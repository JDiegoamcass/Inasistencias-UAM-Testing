<?php

namespace App\Http\Controllers;

use App\Models\Solicitud;
use Illuminate\Http\Request;

class SecretariaSolicitudController extends Controller
{
    public function index()
    {
        $solicitudes = Solicitud::with('user')->where('estado', 'pendiente')->get();
        return view('secretaria.solicitudes.index', compact('solicitudes'));
    }

    public function update(Request $request, Solicitud $solicitud)
    {
        $request->validate([
            'estado' => 'required|in:aprobado,rechazado',
        ]);

        $solicitud->update([
            'estado' => $request->estado,
        ]);

        $mensaje = $request->estado === 'aprobado' ? 'Solicitud aprobada exitosamente.' : 'Solicitud rechazada.';
        
        return redirect()->route('secretaria.solicitudes.index')->with('success', $mensaje);
    }
} 