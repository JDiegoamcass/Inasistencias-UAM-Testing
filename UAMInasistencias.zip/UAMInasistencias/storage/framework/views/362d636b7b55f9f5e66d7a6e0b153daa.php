<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio de Sesión - UAM</title>
    <link rel="icon" href="<?php echo e(asset('images/uam-logo.png')); ?>" type="image/x-icon">
    <meta name="description" content="Inicio de sesión en el sistema de inasistencias de la Universidad Americana.">
    <meta name="keywords" content="UAM, inasistencias, universidad, alumnos, profesores, gestión">
    <meta name="author" content="Scrum masters">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        uam: '#009DA9'
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-uam min-h-screen flex items-center justify-center">

    <div class="bg-white w-full max-w-sm rounded-lg shadow-lg p-8">

        <!-- Logo -->
        <div class="text-center mb-6">
            <img src="<?php echo e(asset('images/uam-logo.png')); ?>" alt="Logo UAM" class="mx-auto w-24 h-24 object-contain">
            <h2 class="text-xl font-semibold text-gray-800 mt-4">INICIAR SESIÓN</h2>
        </div>

        <!-- Mostrar errores de validación -->
        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Formulario -->
        <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <!-- Correo UAM -->
            <div>
                <label class="text-sm text-gray-700 block">CORREO UAM</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" required
                    placeholder="tu.correo@uamv.edu.ni"
                    class="w-full mt-1 p-3 rounded bg-gray-100 text-gray-800 outline-none focus:ring-2 focus:ring-uam focus:bg-white <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Contraseña -->
            <div>
                <label class="text-sm text-gray-700 block">CONTRASEÑA</label>
                <input type="password" name="password" required
                    placeholder="Ingresa tu contraseña"
                    class="w-full mt-1 p-3 rounded bg-gray-100 text-gray-800 outline-none focus:ring-2 focus:ring-uam focus:bg-white <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Botón -->
            <div class="pt-4">
                <button type="submit" class="w-full bg-uam text-white font-semibold py-3 rounded hover:bg-cyan-800 hover:scale-105 transition">
                    INICIAR SESIÓN
                </button>
            </div>
        </form>

        <!-- Enlaces -->
        <div class="flex justify-between mt-6 text-sm">
            <a href="<?php echo e(route('register')); ?>" class="text-uam hover:underline">Crear cuenta</a>
            <a href="<?php echo e(route('password.request')); ?>" class="text-uam hover:underline">¿Olvidaste tu contraseña?</a>
        </div>

    </div>

</body>
</html>
<?php /**PATH C:\Users\Alex Diaz\Desktop\Laravel\UAM-Inasistencia-Sistema\UAMInasistencias\resources\views/auth/login.blade.php ENDPATH**/ ?>