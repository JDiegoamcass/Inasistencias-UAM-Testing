<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" href="<?php echo e(asset('images/uam-logo.png')); ?>" type="image/x-icon">
        <meta name="description" content="Sistema de inasistencias de la Universidad Americana.">
        <meta name="keywords" content="UAM, inasistencias, universidad, alumnos, profesores, gestión">
        <meta name="author" content="Scrum masters">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo e(config('app.name', 'Sistemas de Inasistencias - UAM')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="bg-gray-900 text-gray-100 min-h-screen">
        <div class="font-sans antialiased min-h-screen bg-gray-900">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-gray-900 border-b border-gray-800 shadow-lg">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main class="flex-grow">
                <?php echo e($slot); ?>

            </main>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\Alex Diaz\Desktop\Laravel\UAM-Inasistencia-Sistema\UAMInasistencias\resources\views/layouts/app.blade.php ENDPATH**/ ?>