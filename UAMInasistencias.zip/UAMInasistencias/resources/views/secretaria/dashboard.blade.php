<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-white leading-tight">
            {{ __('Panel de Secretaría Académica') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-white">
                    <h2 class="text-2xl font-bold mb-6 text-white">Panel de Secretaría Académica</h2>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <a href="{{ route('secretaria.profesores.index') }}" 
                           class="block p-6 bg-blue-600 hover:bg-blue-700 rounded-lg shadow-lg transition duration-300">
                            <div class="text-center">
                                <div class="text-3xl mb-2">👨‍🏫</div>
                                <h3 class="text-lg font-semibold mb-2">Gestionar Profesores</h3>
                                <p class="text-blue-200">Administrar información de profesores</p>
                            </div>
                        </a>
                        
                        <a href="{{ route('secretaria.clases.index') }}" 
                           class="block p-6 bg-green-600 hover:bg-green-700 rounded-lg shadow-lg transition duration-300">
                            <div class="text-center">
                                <div class="text-3xl mb-2">📚</div>
                                <h3 class="text-lg font-semibold mb-2">Gestionar Clases</h3>
                                <p class="text-green-200">Administrar clases y asignaciones</p>
                            </div>
                        </a>
                        
                        <a href="{{ route('secretaria.solicitudes.index') }}" 
                           class="block p-6 bg-yellow-600 hover:bg-yellow-700 rounded-lg shadow-lg transition duration-300">
                            <div class="text-center">
                                <div class="text-3xl mb-2">📋</div>
                                <h3 class="text-lg font-semibold mb-2">Solicitudes Pendientes</h3>
                                <p class="text-yellow-200">Revisar solicitudes de inasistencias</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 