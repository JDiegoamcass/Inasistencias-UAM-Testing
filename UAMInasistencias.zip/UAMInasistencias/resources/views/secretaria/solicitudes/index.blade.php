<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-white leading-tight">
            {{ __('Solicitudes Pendientes') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-white">
                    <h2 class="text-2xl font-bold mb-6 text-white">Solicitudes de Inasistencia Pendientes</h2>

                    @if(session('success'))
                        <div class="bg-green-600 text-white p-4 rounded-lg mb-6">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if($solicitudes->count() > 0)
                        <div class="overflow-x-auto">
                            <table class="w-full table-auto border-collapse border border-gray-600">
                                <thead>
                                    <tr class="bg-gray-700">
                                        <th class="border border-gray-600 p-3 text-left">Estudiante</th>
                                        <th class="border border-gray-600 p-3 text-left">Fecha de Solicitud</th>
                                        <th class="border border-gray-600 p-3 text-left">Comentario</th>
                                        <th class="border border-gray-600 p-3 text-left">Estado</th>
                                        <th class="border border-gray-600 p-3 text-left">Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($solicitudes as $solicitud)
                                        <tr class="hover:bg-gray-700">
                                            <td class="border border-gray-600 p-3">{{ $solicitud->user->name }}</td>
                                            <td class="border border-gray-600 p-3">{{ $solicitud->fechaSolicitud }}</td>
                                            <td class="border border-gray-600 p-3">{{ $solicitud->comentario }}</td>
                                            <td class="border border-gray-600 p-3">
                                                <span class="px-2 py-1 text-xs rounded-full 
                                                    @if($solicitud->estado === 'pendiente') bg-yellow-600 text-yellow-200
                                                    @elseif($solicitud->estado === 'aprobado') bg-green-600 text-green-200
                                                    @else bg-red-600 text-red-200 @endif">
                                                    {{ ucfirst($solicitud->estado) }}
                                                </span>
                                            </td>
                                            <td class="border border-gray-600 p-3">
                                                @if($solicitud->estado === 'pendiente')
                                                    <form method="POST" action="{{ route('secretaria.solicitudes.aprobar-rechazar', $solicitud->id) }}" class="inline">
                                                        @csrf @method('PUT')
                                                        <input type="hidden" name="estado" value="aprobado">
                                                        <button type="submit" 
                                                                class="text-green-400 hover:text-green-300 mr-3"
                                                                onclick="return confirm('¿Aprobar esta solicitud?')">
                                                            ✅ Aprobar
                                                        </button>
                                                    </form>
                                                    <form method="POST" action="{{ route('secretaria.solicitudes.aprobar-rechazar', $solicitud->id) }}" class="inline">
                                                        @csrf @method('PUT')
                                                        <input type="hidden" name="estado" value="rechazado">
                                                        <button type="submit" 
                                                                class="text-red-400 hover:text-red-300"
                                                                onclick="return confirm('¿Rechazar esta solicitud?')">
                                                            ❌ Rechazar
                                                        </button>
                                                    </form>
                                                @else
                                                    <span class="text-gray-400">Procesada</span>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="text-center py-8">
                            <div class="text-6xl mb-4">📋</div>
                            <h3 class="text-xl font-semibold text-gray-300 mb-2">No hay solicitudes pendientes</h3>
                            <p class="text-gray-400">Todas las solicitudes han sido procesadas.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout> 