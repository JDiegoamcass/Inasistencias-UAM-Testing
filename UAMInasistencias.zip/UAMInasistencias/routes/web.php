<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SolicitudController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Rutas públicas para estudiantes y profesores
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Rutas para solicitudes de estudiantes
    Route::resource('solicitudes', SolicitudController::class)->parameters([
        'solicitudes' => 'solicitud'
    ]);
});

// Incluir rutas de autenticación
require __DIR__.'/auth.php';

// Incluir rutas de secretaria (protegidas)
require __DIR__.'/web_secretaria_routes.php';
