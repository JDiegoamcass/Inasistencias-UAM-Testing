<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SecretariaClaseController;
use App\Http\Controllers\SecretariaProfesorController;
use App\Http\Controllers\SecretariaSolicitudController;

// Rutas de Secretaria - Solo accesibles para usuarios autenticados con rol de secretaria
Route::middleware(['auth', 'role:secretaria'])->prefix('secretaria')->name('secretaria.')->group(function () {
    // Dashboard de secretaria
    Route::get('/dashboard', function () {
        return view('secretaria.dashboard');
    })->name('dashboard');

    // Gestión de profesores
    Route::resource('profesores', SecretariaProfesorController::class);

    // Gestión de clases
    Route::resource('clases', SecretariaClaseController::class);

    // Bandeja de solicitudes pendientes
    Route::get('/solicitudes/pendientes', [SecretariaSolicitudController::class, 'index'])->name('solicitudes.index');
    Route::put('/solicitudes/{solicitud}/aprobar-rechazar', [SecretariaSolicitudController::class, 'update'])->name('solicitudes.aprobar-rechazar');
}); 